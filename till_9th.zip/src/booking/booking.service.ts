import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Booking } from "src/booking/booking";
import { Observable } from "rxjs";

@Injectable({
    providedIn : 'root'
})


export class BookingService {

    constructor(private http : HttpClient){

    }

    url='http://localhost:9080/booking';

    enroll(booking : Booking){ 

        console.log("service called");
        return this.http.post("http://localhost:9080/booking", booking);
    }
    

}
