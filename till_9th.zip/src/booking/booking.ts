export class Booking {
     
constructor(

public username ='',
public password ='',
public email='',
public number='',
public date='',
public todate=''
){}

}