import { Injectable } from "@angular/core";
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {tap, catchError} from 'rxjs/operators';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router/router";
import { AuthenticationService } from "src/Gaurd/authentication.service";

@Injectable({
    providedIn : 'root'
})
   
export class pageGaurdService implements CanActivate{
    
constructor(private router:Router,
     private pgService:AuthenticationService){}


    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) 
    { 
        if (this.pgService.isUserLogged())
        return true;
 this.router.navigate(['login']);
        return false;
        }
}