import{ Component} from '@angular/core';

@Component ({
    selector: 'home',
    templateUrl : './Home.component.html',
    styleUrls :['./Home.component.css']

})

export class HomeComponent{
    imgHeight : number = 600;
 imgWidth : number = 800;
}