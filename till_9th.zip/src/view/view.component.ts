

import { Component } from "@angular/core";

@Component({
    selector:'view',
    templateUrl:'./view.component.html'
})


export class ViewComponent{
}