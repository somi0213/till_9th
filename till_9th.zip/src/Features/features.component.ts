import {Component, OnInit, OnChanges, OnDestroy} from '@angular/core';
import { IPlace } from './Features';
import { FeatureService } from "./features.service";
import {Router} from "@angular/router";


@Component({

  selector:'features', 
  templateUrl:'./features.component.html'
 
  
})

export class FeaturesComponent implements  OnInit,OnChanges,OnDestroy{
  
  // imgWidth:number=400;
  // imgHeight:number=180;
   errorMessage:string;

  
  places : IPlace[]= []; // I AM CALLING IPLACE , WHICH IS IN FEATURES.SERVICE.TS

 constructor(private featureservice:FeatureService, private router:Router) {
  console.log("At constructor ");
 
}
ngOnInit(): void {
 this.featureservice.getPlace().subscribe(
  places =>{
  this.places = places;
 // this.searchedMovies = this.movies;
},
error =>this.errorMessage = error

  );
}  
  

  ngOnChanges(): void {

  console.log("At the Change detection phase!");  
  }
  ngOnDestroy(): void {
    console.log("Destroying the component");
  }

  delPlaces(id:number):void{
    this.featureservice.delPlaces(id).subscribe(
      data=>{console.log(data);
      this.featureservice.getPlace().subscribe(data=>
      {
        this.places=data;
      })
    },
    // ()=>{
    //   this.router.navigate([/view]);
    // }
    )
  }
  

}

